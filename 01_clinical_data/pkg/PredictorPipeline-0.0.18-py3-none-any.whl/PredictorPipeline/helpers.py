import os
from pathlib import Path


class PathValidator:
    """ gets a path of a folder or a file and returns a valid (existing) path or default path to store something
    1. path = file: actual working directory/file -> check if file already exists (if yes: message replacement)
    2. path = folder/file: this directory with filename -> check if file already exists (if yes: message replacement)
    3. path = folder: this folder with default name -> check if file already exists (if yes: change default name!)
    4. path = None: actual working folder / default name -> check if file already exists (if yes: change default name!)
    """

    def __init__(self, path, default_name='file', valid_suffix=None):
        self.path = path
        self.validated_path = None
        self.valid_suffix = valid_suffix
        self.default_name = default_name
        self.cwdir = None
        self._build_valid_suffices()
        self._get_current_working_dir()
        self._validate_path()

    def get_validated_path(self):
        return self.validated_path

    def _get_current_working_dir(self):
        self.cwdir = Path(os.getcwd())

    def _build_valid_suffices(self):
        if self.valid_suffix is None:
            self.valid_suffix = []

    def _validate_path(self):
        path = self._path_conversion(self.path)

        if path is None:
            path = self.cwdir.joinpath(self.default_name)

        elif path.is_dir():  # without file
            path = path.joinpath(self.default_name)

        elif path.parent.name == '' and path.suffix in self.valid_suffix:
            path = self.cwdir.joinpath(path)

        else:
            if path.parent.is_dir() and path.suffix in self.valid_suffix:
                path = path
            else:
                path = None

        self.validated_path = path

    @staticmethod
    def _path_conversion(path):
        if path is not None:
            try:
                path = Path(path)
            except TypeError:
                raise Exception(f"conversion from '{path}' to Path-object didn't work!")
        return path
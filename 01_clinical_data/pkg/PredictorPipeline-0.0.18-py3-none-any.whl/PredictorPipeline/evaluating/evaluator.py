import pandas as pd
from PredictorPipeline.predicting.predictor import Predictor, Storage
from typing import List, Optional, Union, Dict
from sklearn.utils import estimator_html_repr
from PredictorPipeline.helpers import PathValidator
import itertools
import plotly.graph_objects as go
import copy


# https://towardsdatascience.com/advanced-permutation-importance-to-explain-predictions-ead7de26eed4


class Evaluator:

    def __init__(self,
                 predictor: Predictor,
                 test_data: Optional[Union[None, pd.DataFrame]] = None
                 ):
        self.predictor = self._check_predictor_instance(predictor)
        self.X_test, self.y_test = self._build_test_data(test_data)
        self.summary_object = {}
        self._scoring, self._train_score, self._used_models = self._get_predictor_params()
        self._prediction_type = self.predictor.prediction_type
        self._metrics = None
        self._summary_table = None
        self.ranks = {"best_sim_algo": None, "best_sim": None, "best": None}
        self._refit = self._get_refit()

    @staticmethod
    def _intersection(lst1, lst2):
        lst3 = [value for value in lst1 if value in lst2]
        return lst3

    @staticmethod
    def _check_predictor_instance(predictor):
        if not isinstance(predictor, Predictor):
            raise Exception(f"predictor has to be an instance of Predictor")
        return predictor

    @classmethod
    def load(cls, path=None):
        return Storage.load(path=path)

    def save(self, path=None):
        Storage(path=path).store(obj=self)

    def get_summary_object(self, type="default"):
        """ builds a summary dictionary of class evaluator (exp. for app-cards,...)
        Args:
            type: one out of 'default' or 'md' as str. 'md' formats output with markdown-style

        Returns: dictionary with summary of object

        """
        self._build_summary_object(type=type)
        return self.summary_object

    def get_models(self,
                   mode: Optional[Union[str, list]] = "all",
                   type: Optional[str] = 'fitted_obj',
                   metric: Optional[Union[None, str]] = None
                   ) -> Union[pd.DataFrame,]:
        """
        get models from simulations according to its 'id' or other parameters and returns it as
        pd.Dataframe or fitted object.

        Args:
            mode: one out of 'all', 'best', 'best_sim', 'best_sim_algo' id (as string) or list of id's
            type: one out of 'fitted_obj' for fitted object (to calculate predictions or else), 'df' for pd.DataFrame
            metric: one out of used metrics (exp. accuracy, rmse, ...) or None (default -> use standard metric).
            Metric is used to find 'best' model according to this metric in case of mode='best' """

        if self._summary_table is None:
            self._build_summary_table()

        self._build_ranks(metric=metric)

        if mode == "all":
            ids = {i: i for i in self._summary_table['id']}
        elif mode == "best":
            ids = {'_': self.ranks[mode]}
        elif mode in ['best_sim', 'best_sim_algo']:
            ids = self.ranks[mode]
        elif isinstance(mode, str):
            ids = self._summary_table[self._summary_table['id'] == mode]['id']
            if len(ids) != 1:
                ids = {}
            else:
                ids = {mode: ids.values[0]}
        elif isinstance(mode, list):
            ids = {i: i for i in self._summary_table['id'] if i in mode}
        else:
            ids = {}

        results = {}

        # TODO: what happens if there is no cv_results_ ...?
        # TODO: -> catch if mode='all' and these are +1000 algorithms
        if type == 'fitted_obj':
            for id in ids.values():
                sim, model, idx = id.split("-")
                model_for_id = copy.deepcopy(
                    self.predictor.fitted_results.get(int(sim)).get(self._used_models.get(model)).estimator)
                params_for_id = \
                    self.predictor.fitted_results.get(int(sim)).get(self._used_models.get(model)).cv_results_.get(
                        'params')[
                        int(idx)]
                model_for_id.set_params(**params_for_id)
                fitted_model = model_for_id.fit(X=self.predictor.X_train, y=self.predictor.y_train)
                results.update({id: fitted_model})

        elif type == 'df':
            if mode == "all":
                results = self._summary_table
            else:
                results = self._summary_table[self._summary_table.id.isin(ids.values())]

        return results

    def get_summary_plot(self,
                         mode: Optional[str] = "all",
                         metric: Optional[Union[str, None]] = None,
                         color: Optional[List[str]] = "metric",
                         x: Optional[str] = "algorithm",
                         boxpoints: Optional[str] = 'all',
                         boxmean: Optional[str] = 'True',
                         jitter: Optional[float] = 0.2,
                         opacity: Optional[float] = 1,
                         yrange: Optional[List[float]] = [0.0, 1.0],
                         path: Optional[str] = None,
                         df: Optional[pd.DataFrame] = None
                         ):
        """
        Args:
            mode: one out of 'all', 'best', 'best_sim', 'best_sim_algo' id or list of id's
            metric: name of metric for finding best model as string. Only usable if model="best"
            color: list of strings, one or multiple out of ['algorithm', 'group', 'metric' 'sim', 'params' or None]
            x: parameter for x-axis: one out of ['algorithm', 'group', 'metric', 'sim', 'params']
            boxpoints: one out of 'all', 'suspectedoutliers', 'outliers', 'False'
            boxmean: one out of 'True', 'sd', 'False'
            jitter: a float value between 0 and 1 for jittering boxpoints
            opacity: a float value between 0 and 1 for opacity
            yrange: a list of 2 floats for starting and endpoint of y-axis scale
            path: where should the plots be stored? If None (default) is set, the plots are only returned but not stored

        Returns: plotly figure
        """
        if df is None:
            df = self.get_models(mode=mode, metric=metric, type="df")
        df_mod = self._build_summary_plot_data(df)

        if df_mod is not None:
            fig = self._build_summary_plot_figure(boxmean, boxpoints, color, df_mod, jitter, opacity, x, yrange)
        else:
            fig = {}

        if path is None:
            return fig
        else:
            default_name = f'summary_plot.html'
            store_path = PathValidator(path, default_name=default_name,
                                       valid_suffix=['.html']).get_validated_path()
            if store_path is not None:
                fig.write_html(str(store_path))
            else:
                raise Exception(f"could not write plots to disk! Unknown Path: {path}")

    def _build_test_data(self, test_data):
        if test_data is None:
            if self.predictor.X_test is not None and self.predictor.y_test is not None:
                X_test = self.predictor.X_test
                y_test = self.predictor.y_test
            else:
                X_test = None
                y_test = None
        else:
            if not isinstance(test_data, pd.DataFrame):
                raise Exception(f"'test_data has to be an instance of pd.DataFrame")
            if self.predictor.target not in test_data.columns:
                raise Exception(f"'test_data' does not contain the target-column '{self.predictor.target}'")
            else:
                y_test = test_data[self.predictor.target]
                X_test = test_data.drop(self.predictor.target, axis=1)
                if X_test.shape[1] != self.predictor.X_train.shape[1]:
                    raise Exception(f"X_train ({self.predictor.X_train.shape[1]}) and "
                                    f"X_test ({X_test.shape[1]}) have not the same shape!")
                if len(self._intersection(list(X_test.columns), list(self.predictor.X_train.columns))) != X_test.shape[
                    1]:
                    raise Exception(f"Not all columns in X_test and X_train seems to have same name!")

        return X_test, y_test

    def _build_summary_table(self):
        """
        builds a summary table with results of all simulations and all combinations of hyper-parameters

        Args:
            -
        Returns:
            None
        """
        df = self._collect_results()
        df = self._replace_score_with_metric_unit(df)
        df = self._add_test_scores(df)
        self._calculate_metrics()
        df = self._remove_splits(df)  # remove splits due incompatible cv's
        df = self._calculate_mean_train_diff(df)

        df['sim_algo'] = df['id'].apply(lambda x: '-'.join(x.split("-")[:-1]))
        # rearrange columns
        first_cols = ['sim', 'sim_algo', 'id', 'algorithm']
        cols = list(df.columns)
        not_in_first_cols = [i for i in cols if i not in first_cols]
        new_cols = first_cols + not_in_first_cols
        df = df[new_cols]
        self._summary_table = df

    def _calculate_mean_train_diff(self, df):
        # build mean_diff (mean_train -mean_validation)
        mean_train = [i for i in df.columns if "mean_train" in i]
        if mean_train:
            if len(self.predictor.scorer_names) != 0:
                for item in self.predictor.scorer_names:
                    df[f'mean_diff_{item}'] = df[f'mean_train_{item}'] - df[f'mean_validation_{item}']
            else:
                if self.predictor.prediction_type == "classifier":
                    df[f'mean_diff_accuracy'] = df[f'mean_train_accuracy'] - df[f'mean_validation_accuracy']
                else:
                    df[f'mean_diff_r2'] = df[f'mean_train_r2'] - df[f'mean_validation_r2']
        return df

    def _remove_splits(self, df):
        columns = ['id', 'sim', 'algorithm', 'params'] + self._metrics
        df = df.loc[:, columns]
        return df

    def _add_test_scores(self, df):
        # only best model for a simulation/algorithm combination (could also be done for every combination...)
        if self.X_test is not None and self.y_test is not None:
            test_scores = []
            for sim in list(self.predictor.fitted_results.keys()):
                for algorithm in list(self.predictor.fitted_results.get(sim).keys()):
                    scorer_name = []
                    score = []
                    model = self.predictor.fitted_results.get(sim)[algorithm]
                    if isinstance(model.scorer_, dict):
                        preds = model.predict(self.X_test)
                        keys = model.scorer_.keys()
                        for key in keys:
                            sc = model.scorer_.get(key)
                            scorer_name.append(key)
                            score.append(sc._score_func(self.y_test, preds))
                    else:
                        scorer_name.append(self._scoring[0])
                        score = [model.score(self.X_test, self.y_test)]  # only for best_estimator...
                    simple_list = [[sim, algorithm] + score]
                    df_testscore = pd.DataFrame(simple_list, columns=['sim', 'algorithm'] + [f"mean_test_{i}" for i in
                                                                                             scorer_name])  # TODO: replace 'mean' with better word...
                    test_scores.append(df_testscore)
            test_scores = pd.concat(test_scores)
            df = pd.merge(df, test_scores, on=['sim', 'algorithm'])
        return df

    def _calculate_metrics(self):
        """
        calculates train and test metrics according to given metric and if train score was returned or not.

        Args:
            -
        Returns:
            None
        """
        if self.X_test is not None:
            if self._train_score is not False:
                self._metrics = [i[0] + i[1] for i in
                                 itertools.product(['mean_train_', 'mean_validation_', 'mean_test_'], self._scoring)]
            else:
                self._metrics = [i[0] + i[1] for i in
                                 itertools.product(['mean_validation_', 'mean_test_'], self._scoring)]
        else:
            if self._train_score is not False:
                self._metrics = [i[0] + i[1] for i in
                                 itertools.product(['mean_train_', 'mean_validation_'], self._scoring)]
            else:
                self._metrics = [i[0] + i[1] for i in itertools.product(['mean_validation_'], self._scoring)]

    def _replace_score_with_metric_unit(self,
                                        df: pd.DataFrame
                                        ) -> pd.DataFrame:
        """
        replace 'score' with correct unit. If only one metric is set (exp. accuracy) the column is called 'score'
        by default. This will be replaced with the name of the according metric (exp. test_score -> test_accuracy)
        """
        if self._scoring is None:  # take default scorer (accuracy for classification and ? for regression)
            if self._prediction_type == 'classifier':
                self._scoring = ["accuracy"]
            else:
                self._scoring = ["?"]  # TODO
            df = self._replace_score(df)
        elif isinstance(self._scoring, str):
            self._scoring = [self._scoring]
            df = self._replace_score(df)
        elif isinstance(self._scoring, list):
            df = self._replace_score(df)
        else:  # in case if dict
            self._scoring = list(self._scoring.keys())
        return df

    def _collect_results(self
                         ) -> pd.DataFrame:
        """
        collects all results in a pandas DataFrame and add a unique id for every row (a-b-c):
        a -> simulation number,
        b -> algorithm number,
        c -> consecutive number

        Args:
            -
        Returns:
            pandas DataFrame
        """

        dfs = []  # collect results
        for sim_nr, sim in self.predictor.fitted_results.items():
            for idx, est_name in enumerate(sim.keys()):
                this_df = pd.DataFrame(sim[est_name].cv_results_)

                # TODO: here rename test -> validation
                new_colnames = [w.replace('_test_', '_validation_') for w in list(this_df.columns)]
                this_df.columns = new_colnames

                this_df['sim'] = sim_nr
                this_df['algorithm'] = est_name
                this_df['id'] = [f"{sim_nr}-{idx}-{i}" for i in list(this_df.index)]
                this_df = this_df.loc[:, ~ this_df.columns.str.contains("param_")]
                dfs.append(this_df)
        df = pd.concat(dfs, ignore_index=True)
        return df

    def _build_ranks(self,
                     metric: Union[None, str],
                     ) -> dict:
        """
        catches best models according to chosen metric from summary_table

        Args:
            metric: name of desired metric (exp. accuracy, f1, ...)

        Returns:
            dictionary with 'best', 'best_sim' and 'best_sim_algo' as key and 'id' as list of values
        """

        if metric is None:
            validation_list = [i for i in self._metrics if "validation_" in i]
            rank_metric = validation_list[0]
        else:
            if metric not in self._scoring:
                raise Exception(f"metric '{metric}' was not fitted. Use one of {self._scoring}")
            rank_metric = f"mean_validation_{metric}"

        df = self._summary_table

        # best per algorithm and simulation
        # df['sim_algo'] = df['id'].apply(lambda x: '-'.join(x.split("-")[:-1]))
        grouped_df = df.groupby('sim_algo')
        best_sim_algo = {}
        for name, group in grouped_df:
            best_id = group[group[rank_metric] == max(group[rank_metric])]['id'].values[
                0]  # TODO: whats best? Min? Max?
            best_sim_algo.update({name: best_id})
        self.ranks.update({'best_sim_algo': best_sim_algo})

        # best per simulation (test_size, random_state)
        grouped_df = df.groupby('sim')
        best_sim = {}
        for name, group in grouped_df:
            best_id = group[group[rank_metric] == max(group[rank_metric])]['id'].values[0]
            best_sim.update({f'{name}': best_id})
        self.ranks.update({'best_sim': best_sim})

        # overall
        self.ranks.update({"best": df[df[rank_metric] == max(df[rank_metric])]['id'].values[0]})

    def _get_predictor_params(self):
        scoring, train_score, used_models = None, None, None
        if self.predictor.fitted_results:
            used_models = {str(idx): algoritm for idx, algoritm in
                           enumerate(self.predictor.fitted_results.get(0).keys())}
            scoring = self.predictor.fitted_results.get(0).get(used_models.get('0')).scoring
            train_score = self.predictor.fitted_results.get(0).get(used_models.get('0')).return_train_score
        return scoring, train_score, used_models

    def _replace_score(self,
                       df: pd.DataFrame
                       ) -> pd.DataFrame:

        cols = list(df.columns)
        cols_0 = [i.replace('validation_score', f'validation_{self._scoring[0]}') for i in cols]
        cols_1 = [i.replace('train_score', f'train_{self._scoring[0]}') for i in cols_0]
        df.columns = cols_1
        return df

    def _build_summary_plot_data(self,
                                 df: pd.DataFrame
                                 ) -> pd.DataFrame:
        """
        build data for subsequently plotting

        Args:
            df: pd.DataFrame with raw data

        Returns:
            modified pandas DataFrame

        """
        if df.shape == (0, 0):
            return None
        else:
            df_mod = df.melt(id_vars=['id', 'sim', 'algorithm', 'params'],
                             value_vars=self._metrics)

        def split(s):
            var = s.variable
            var = var.replace("_", ".", 2)  # replace first 2 occurrences of '_' by '.' to split afterwards
            return var

        df_mod[['variable']] = df_mod.apply(split, axis=1)
        df_mod[['stat', 'group', 'metric']] = df_mod.variable.str.split(".", expand=True)
        df_mod['params'] = df_mod.params.apply(lambda x: str(x))
        return df_mod

    def _get_refit(self):
        refit = self.predictor.fitted_results.get(0).get(self._used_models['0']).refit
        if refit is True:
            refit = self._scoring
        return refit

    @staticmethod
    def _build_summary_plot_figure(
            boxmean: str,
            boxpoints: str,
            color: List[str],
            df_mod: pd.DataFrame,
            jitter: float,
            opacity: float,
            x: str,
            yrange: List[float],
    ) -> go.Figure:

        """
        builds figure for summary plot

        Args:
            - see Args: get_summary_plot()
        Returns:
            Figure object
        """
        bp = lambda x: x if x != 'False' else eval(x)
        bm = lambda x: x if x == 'sd' else eval(x)

        fig = go.Figure()
        grouped = df_mod.groupby(color)
        for name, group in grouped:
            fig.add_trace(go.Box(
                y=group['value'],
                x=group[x],
                boxpoints=bp(boxpoints),
                boxmean=bm(boxmean),
                jitter=jitter,
                opacity=opacity,
                name=str(name),
                customdata=group.loc[:,
                           ['id', 'algorithm', 'params', 'stat', 'group', 'metric']],

                hovertemplate=
                "<b>score:</b> %{y} <br><br>" +
                "id: %{customdata[0]} <br>" +
                "algorithm: %{customdata[1]} <br>" +
                "parameters: %{customdata[2]} <br>" +
                "stat: %{customdata[3]} <br>" +
                "group: %{customdata[4]} <br>" +
                "metric: %{customdata[5]} <br>"
            ))

        fig.update_layout(
            template='plotly_white',
            boxmode='group',  # group together boxes of the different traces for each value of x
            yaxis_range=[yrange[0], yrange[1]]
        )

        return fig

    def _build_summary_object(self, type):

        def get_simulations(type):
            sim = self.predictor.cv
            sim_desc = list(sim.values())
            if type == "md":
                sim = [f"{n}: {str(i)}\n" for n, i in enumerate(sim_desc)]
                sim = '\n'.join(sim)
            else:
                sim = [f"{n}: {str(i)}\n" for n, i in enumerate(sim_desc)]
            return sim

        def get_used_models(type):
            used_models = list(self.predictor.fitted_results[0].keys())
            if type == "md":
                used_models = [f"* {i} ({n})\n" for n, i in enumerate(used_models)]
            else:
                used_models = '\n'.join(used_models)
            return used_models

        def get_train_test_size(type):
            shape_train = self.predictor.X_train.shape
            if type == "md":
                formatted_shape_train = f"* X_train: ({shape_train[0]} observations, {shape_train[1]} features)"
            else:
                formatted_shape_train = f"X_train: ({shape_train[0]} observations, {shape_train[1]} features)"
            if self.predictor.X_test is not None:
                shape_test = self.predictor.X_test.shape
                if type == "md":
                    formatted_shape_test = f"* X_test: ({shape_test[0]} observations, {shape_test[1]} features)"
                else:
                    formatted_shape_test = f"X_test: ({shape_test[0]} observations, {shape_test[1]} features)"
                formatted_shape = "\n".join(formatted_shape_train, formatted_shape_test)
            else:
                formatted_shape = formatted_shape_train
            return formatted_shape

        self.summary_object.update({
            'obj_type': self.predictor.prediction_type,
            'fit_time': self.predictor.fit_time,
            'grid': self.predictor.grid,
            'target': self.predictor.target,
            'used_models': get_used_models(type=type),
            'simulations': get_simulations(type=type),
            'no_models': self.get_models(mode="all", type="df").shape[0],
            'fig_pipeline': estimator_html_repr(self.predictor.pipeline),
            'scorer': self.predictor.scorer_names,  # TODO!
            'parameters': "\n".join([str(self.predictor.parameters[0]),  # TODO!
                                     str(self.predictor.parameters[1])]),
            'size_train_test_data': get_train_test_size(type=type)
        })


if __name__ == '__main__':
    pass

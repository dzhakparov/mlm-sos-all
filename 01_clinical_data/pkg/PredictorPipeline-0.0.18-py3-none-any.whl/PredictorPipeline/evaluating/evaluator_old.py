import seaborn as sns
import matplotlib.pyplot as plt
import math
import pandas as pd
from PredictorPipeline.helpers import PathValidator
from sklearn.utils import estimator_html_repr
from sklearn.model_selection import GridSearchCV, KFold
from mlxtend.feature_selection import SequentialFeatureSelector as SFS

from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, BaggingClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.tree import DecisionTreeClassifier, ExtraTreeClassifier
from mlxtend.plotting import plot_sequential_feature_selection as plot_sfs

from PredictorPipeline.predicting.predictor import Predictor, Storage
from typing import List, Optional, Union, Dict


class Evaluator_old:
    """ evaluates and analyzes a .csv simulation file (build with PredictorPipeline.predictor) for best model,
    calculates feature importance on overall data with desired model(s) und generates several evaluation plots
    """

    VALID_SETS = ('train', 'test', 'cv')
    COLORS = {'train': 'red', 'cv': 'blue', 'test': 'green'}

    def __init__(self, working_file, target, simulation_file, pipe, params=None):
        """
        :param working_file: pandas DataFrame with raw values
        :param target: target feature as string
        :param simulation_file: .csv-file with simulation results
        :param pipe: used sklearn Pipeline
        :param params: used parameter tuple
        """
        self.working_file = working_file
        self.target = target
        self.simulation_file = simulation_file
        self.pipe = pipe
        self.params = params
        self.fitted_model = None
        self.X = None
        self.y = None
        self.best_algorithm = None
        self.best_param = None
        self.stats = None
        self.all_models = None  # list of all different models (algorithm) in simulation_file
        self.metric = None
        self.metric_aggregation = None
        self.df_feature_importance = None
        self.preprocessed_x = None
        self.models_overview = None
        self.updated_pipe = None
        self.updated_params = None
        self._build_data()
        self._rename_simulation_file()

    def analyze_best_models(self, models=None, test_size=0.25, sorted_by=('test', 'cv'), no_features=None, cv=5):
        """ describes all or selected models (best of) with feature importance (optionally) and some model statistics
        :param models: list of models to be select. If None (default) all available models will be used
        :param test_size: float between 0 and 1
        :param sorted_by: tuple from 'test', 'train' and 'cv'. How should the performance of models be picked/sorted?
        :param no_features: Number of features as int to use for feature importance. If None (default) no feature
            importance will be calculated.
        :param cv: number of cross validations in feature importance. Is only used if no_params is not None.
        """
        all_models = self._get_all_models()
        if models is not None:
            models = [model for model in models if model in all_models]
        else:
            models = all_models

        if models:
            self.models_overview = []
            for model in models:
                model_stats = {}
                self.chose_model(test_size=test_size, model=model, sorted_by=sorted_by)
                model_stats.update({'1_name': self.get_algorithm()})
                model_stats.update({'2_best_param': self.get_best_param()})
                model_stats.update({'3_stats': self.get_stats_model()})
                if no_features is not None:
                    self.calculate_feature_importance(no_features=no_features, cv=cv)
                    model_stats.update({'4_features': self.get_most_important_features(type='list')})
                self.models_overview.append(model_stats)

    def calculate_feature_importance(self, no_features=5, cv=5):
        """
        calculate feature importance with SFS
        :return:
        """
        if self.best_algorithm is None:
            raise Exception(f"There is no fitted model. Please use method 'chose_model'")

        self._update_pipe_and_parameters()
        self._fit_model()

        position_estimator = [idx for idx, i in enumerate(list(self.fitted_model.best_estimator_.named_steps))
                              if i == 'estimator'][0]
        best_estimator = self.fitted_model.best_estimator_.steps.pop(position_estimator)[1]
        self.preprocessed_x = self.fitted_model.best_estimator_.fit_transform(self.X)

        # apply feature importance via SFS
        sfs = SFS(best_estimator,
                  k_features=no_features,
                  forward=True,
                  scoring=self.metric,
                  cv=cv,
                  n_jobs=-1)

        sfs = sfs.fit(self.preprocessed_x, self.y, custom_feature_names=self.preprocessed_x.columns.to_list())
        self.df_feature_importance = pd.DataFrame.from_dict(sfs.get_metric_dict()).T

    def chose_model(self, test_size, model='best', sorted_by=('test', 'cv')):
        """ chooses best model or model by name of given test-size with its best hyper-parameters (major vote)
        :param test_size: test_size to be evaluated as float
        :param model: 'best' (default) or name of model to be analyzed
        :param sorted_by: tuple with name of columns to evaluated as best model (sort will be in ascending order ->
            higher values are better)
        """

        if not isinstance(test_size, float) or test_size > 1 or test_size < 0:
            raise Exception(f"test_size have to be a float between 0 and 1")
        else:
            if not any(self.simulation_file.test_size.isin([test_size])):
                raise Exception(f"test_size have to occur in simulation_file")

        data_red = self.simulation_file[self.simulation_file['test_size'] == test_size]
        best_algorithms = data_red.groupby("algorithm").mean().sort_values(by=list(sorted_by), ascending=False)

        if model == 'best':
            self.best_algorithm = best_algorithms.index[0]
        else:
            if model in self._get_all_models():
                self.best_algorithm = model
            else:
                raise Exception(f"model with name '{model}' was not found in simulation_file")

        best_params = data_red[data_red['algorithm'] == self.best_algorithm].groupby('best_params').count().sort_values(
            by="algorithm", ascending=False)
        self.best_param = self._build_best_param_from_str(best_params)

        self.stats = data_red.loc[:, ['cv', 'train', 'test']][
            data_red['algorithm'] == self.best_algorithm].agg(['mean', 'std'])

    def get_most_important_features(self, type='list'):
        """
        get most important features as pandas DataFrame or as list
        :param type: 'list' (default) or 'df'
        :return: list or pandas DataFrame of m,ost important features selected bei SFS with according algorithm
        """
        if self.df_feature_importance is not None:
            if type == 'list':
                return self._transform_feature_importance_to_list()
            else:
                return self.df_feature_importance

    def get_stats_model(self):
        return self.stats

    def get_algorithm(self):
        return self.best_algorithm

    def get_best_param(self):
        return self.best_param

    def get_best_models_overview(self):
        return self.models_overview

    def plot_scoring_overview(self, path=None, algorithm=None, set=None, test_size=None, colors='algorithm',
                              **kwargs):
        """
        :param colors: one out of 'algorithm' or 'set'
        :param test_size: float or list of floats with valid test_sizes between 0 and 1
        :param set: one or multiple out of 'train', 'test' and 'cv' as tuple. If None (default) all types are chosen.
        :param algorithm: list of algorithms should be plotted. If None (default) all available algorithms are taken
        :param path: None (default) or valid path (incl. file-name with suffix if desired) to store plot.
            If path is not None the plot will not be returned. Valid suffices are .png, .jpg and .pdf
        :param kwargs: additional arguments for sns.catplot like 'col_wrap', ...
        :return: fig object (store = None) or None (store != None)
        """
        self._get_all_models()
        algorithm, set, test_size = self._validating_plotting_options(algorithm, set, test_size)
        data_mod = self.simulation_file.melt(id_vars=['algorithm', 'test_size', 'random_state'],
                                             value_vars=['cv', 'train', 'test'])

        # filter for according subsets
        data_mod = data_mod[data_mod['algorithm'].isin(algorithm)]
        data_mod = data_mod[data_mod['variable'].str.contains(pat=set)]
        data_mod = data_mod[data_mod['test_size'].isin(test_size)]

        kwargs = self._update_kwargs(algorithm, kwargs)

        # build plot
        sns.set_style("whitegrid")
        if colors == 'algorithm':
            sns.catplot(data=data_mod, x='test_size', y='value', col='variable', hue='algorithm',
                        palette='BrBG', kind='box', **kwargs)
        else:
            sns.catplot(data=data_mod, x='test_size', y='value', col='algorithm', hue='variable',
                        palette=Evaluator_old.COLORS, kind='box', **kwargs)

        if path is not None:
            store_path = PathValidator(path, default_name='train_test_analysis.png',
                                       valid_suffix=['.png', '.jpg', '.pdf']).get_validated_path()
            plt.savefig(store_path)

        return plt

    def plot_pipe(self, type='fitted_model', path=None):
        """ plots a html representation of the pipeline (or fitted_model)
        :param type: 'pipe' or 'fitted_model' (filled with its hyper-parameters)
        :param path: path to store output as string
        """
        store_path = PathValidator(path, default_name='fitted_model_pipe.html',
                                   valid_suffix=['.html']).get_validated_path()

        if type == 'pipe':
            with open(store_path, 'w') as f:
                f.write(estimator_html_repr(self.pipe))

        elif type == 'fitted_model':
            if self.fitted_model is None:
                raise Exception(f"No model is chosen. Y have to use method 'chose_model' first!")
            with open(store_path, 'w') as f:
                f.write(estimator_html_repr(self.fitted_model.best_estimator_))
        else:
            raise Exception(f"Type ({type}) is unknown. Use one out of 'pipe' or 'fitted_model'")

    def _build_data(self):
        if self.target in self.working_file:
            self.X = self.working_file.drop([self.target], axis=1)
            self.y = self.working_file[self.target]
        else:
            raise Exception(f"target ({self.target}) was not found in working_file")

    def _rename_simulation_file(self):
        """ renames columns of simulation_file. The metric features are build as follows:
        mean__cv__accuracy, cv__std, mean__train__accuracy, train__std, test__accuracy
        -> metric: kind of aggregation mean/median __ for cv/train __ metric (exp. accuracy/rmse/f1_score/...) -> exp. mean__cv__accuracy
        -> order: cv (metric, std), train (metric, std), test (metric)
        Based on this system the columns are renamed to:
        - cv, cv__std, train, train__std, test
        - additional: new attribute self.metric='accuracy' and self.metric_aggregation='mean' are introduced
        """
        pos_algorithm = self.simulation_file.columns.get_loc("algorithm")
        for idx in [3, 5, 7]:
            item = self.simulation_file.columns[pos_algorithm + idx].split('__')
            if idx != 7:
                self.simulation_file.rename(columns={self.simulation_file.columns[pos_algorithm + idx]: item[1]},
                                            inplace=True)
            else:
                self.simulation_file.rename(columns={self.simulation_file.columns[pos_algorithm + idx]: item[0]},
                                            inplace=True)
            if idx == 3:
                self.metric_aggregation = item[0]
                self.metric = item[2]

    @staticmethod
    def _build_best_param_from_str(params):
        best_param = {}
        param_str = params.index[0]
        param_str = param_str[1:-1]
        param_str_list = str.split(param_str, ',')
        for item in param_str_list:
            item_list = str.split(item, ':')
            for ch in ['"', '\\', "'", " "]:
                item_list[0] = item_list[0].replace(ch, '')
            best_param.update({item_list[0]: eval(item_list[1])})
        return best_param

    def _get_all_models(self):
        """ returns list of all existing models in simulation_file """
        self.all_models = list(self.simulation_file['algorithm'].unique())
        return self.all_models

    def _validating_plotting_options(self, algorithms, sets, test_size):
        if algorithms is not None:
            if not isinstance(algorithms, list) and not isinstance(algorithms, str):
                raise Exception(f"algorithms have to be a single algorithm as string or a list of algorithms")
            if isinstance(algorithms, str):
                algorithms = [algorithms]
            algorithms = [i for i in algorithms if i in self.all_models]
            if not algorithms:
                raise Exception(f"no of this algorithms '{algorithms}' does not occurs in simulation_file. Valid "
                                f"algorithms are {self.all_models}")
        else:
            algorithms = self._get_all_models()

        if sets is not None:
            if not isinstance(sets, tuple) and not isinstance(sets, str):
                raise Exception(f"type has to be one or more item out of {Evaluator_old.VALID_SETS} as tuple")

            if isinstance(sets, str) and sets in Evaluator_old.VALID_SETS:
                s = (sets,)
            elif isinstance(sets, tuple):
                s = [i for i in sets if i in Evaluator_old.VALID_SETS]
                if s:
                    s = tuple(s)
                else:
                    raise Exception(f"type has to be one out of {Evaluator_old.VALID_SETS} but got {sets}")
            else:
                raise Exception(f"type has to be one out of {Evaluator_old.VALID_SETS} but got {sets}")
        else:
            s = Evaluator_old.VALID_SETS

        # build str wit |
        s = [str(i) for i in s]
        s = '|'.join(s)

        available_test_sizes = list(self.simulation_file['test_size'].unique())
        if test_size is not None:
            if not isinstance(test_size, list) and not isinstance(test_size, float):
                raise Exception(f"test_size has to be a float or a list of floats between 0 and 1")
            else:
                ts = [i for i in test_size if i in available_test_sizes]
            if not ts:
                raise Exception(f"no test_size {test_size} found: available are {available_test_sizes}")
        else:
            ts = available_test_sizes

        return algorithms, s, ts

    @staticmethod
    def _update_kwargs(algorithms, kwargs):
        if "col_wrap" not in kwargs and len(algorithms) > 3:
            kwargs.update({'col_wrap': math.ceil(math.sqrt(len(algorithms)))})
        return kwargs

    def _update_pipe_and_parameters(self):

        self.updated_params = self.best_param
        self.updated_params = {key: [value] for key, value in
                               self.updated_params.items()}  # values have to be defined as list
        self.updated_pipe = self.pipe
        self.updated_pipe.steps.pop(-1)  # remove estimator (none)
        self.updated_pipe.steps.append(('estimator', eval(f"{self.best_algorithm}()")))  # add estimator

    def _fit_model(self):
        # additional step to update pipe with params (only best set)! -> model
        kfold = KFold(n_splits=2, shuffle=True)
        self.fitted_model = GridSearchCV(estimator=self.updated_pipe, param_grid=self.updated_params, cv=kfold,
                                         n_jobs=-1,
                                         return_train_score=True, scoring=self.metric, refit=True)
        self.fitted_model.fit(self.X, self.y)

    def _transform_feature_importance_to_list(self):
        feature_list = []
        for idx, item in enumerate(self.df_feature_importance['feature_names']):
            if idx == 0:
                feature_list.append(item[0])
            else:
                diff = [i for i in item if i not in feature_list]
                feature_list.append(diff[0])
        return feature_list


# class FeatureImportance:  # TODO -> not feature importance but model agnostic -> should be implementable sequentially
#     # exp. feature interaction, recursive feature selection, partial dependence plot
#     # (see: https://christophm.github.io/interpretable-ml-book/agnostic.html)
#     # see: https://mljar.com/blog/feature-importance-in-random-forest/
#     def __init__(self, predictor):
#         self.predictor = self._check_predictor(predictor)
#         self.results = {}
#         # https://scikit-learn.org/stable/modules/permutation_importance.html
#         # https://scikit-learn.org/stable/auto_examples/ensemble/plot_forest_importances.html
#         # https://scikit-learn.org/stable/modules/generated/sklearn.feature_selection.RFECV.html
#         # print("okay")
#
#     @staticmethod
#     def _check_predictor(predictor):
#         if not isinstance(predictor, Predictor):
#             raise Exception(f"predictor must be of class Predictor. This object is of {predictor.__class__}")
#         return predictor


#     def _store_summary(self, summary_joblib, summary_csv, scoring):
#         joblib.dump(self.summary, summary_joblib)
#         data = pd.DataFrame(self.summary)
#         data.columns = ['algorithm', 'simulation', 'best_params', f'mean__cv__{scoring[0]}', 'cv__std',
#                         f'mean__train__{scoring[0]}', 'train__std', f'test__{scoring[0]}', 'test_size', 'random_state']
#         data.to_csv(summary_csv)
#
#     def _build_summary(self, X_test, i, random_state, results, test_size, y_test, scoring):
#         for key, value in results.items():
#             y_pred = results.get(key).best_estimator_.predict(X_test)
#             # method_to_call = getattr(sklearn.metrics, f"{scoring[0]}_score")  # scoring function
#             method_to_call = getattr(sklearn.metrics, f"{scoring[0]}")  # TODO: _score (classification), _error (regression)
#             row = [key, i,
#                    results.get(key).best_params_,
#                    results.get(key).best_score_,
#                    results.get(key).cv_results_.get(f'std_test_{scoring[0]}')[results.get(key).best_index_],
#                    results.get(key).cv_results_.get(f'mean_train_{scoring[0]}')[results.get(key).best_index_],
#                    results.get(key).cv_results_.get(f'std_train_{scoring[0]}')[results.get(key).best_index_],
#                    method_to_call(y_test, y_pred),
#                    test_size,
#                    random_state]
#             self.summary.append(row)

#     @staticmethod
#     def _build_results(results):
#         dfs = []  # collect results
#         for key, value in results.items():
#             this_df = pd.DataFrame(value.cv_results_)
#             this_df['name'] = key
#             dfs.append(this_df)
#         df = pd.concat(dfs, ignore_index=True)
#         df = df.loc[:, ~ df.columns.str.contains("param_")]
#         return df
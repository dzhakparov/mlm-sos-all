from typing import List, Optional, Union, Dict
import os
import random
import inspect
import operator
import itertools
import pickle
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.model_selection import KFold
from sklearn.model_selection import BaseCrossValidator, ShuffleSplit
from sklearn.base import BaseEstimator
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.base import is_classifier, is_regressor
from typing import Tuple
from copy import deepcopy
from sklearn import model_selection
from sklearn.base import ClassifierMixin, RegressorMixin
from sklearn.metrics import accuracy_score, precision_score, get_scorer, make_scorer
from typing import List, Optional, Union, Dict
from pathlib import Path
from datetime import datetime
from pprint import pformat

import plotly.graph_objects as go
from PredictorPipeline.helpers import PathValidator
import itertools
import copy
from sklearn.utils import estimator_html_repr


class Predictor:
    """ This class uses a sklearn pipeline object and a param object to run a bunch of cross-validated models

           Args:
            target: name of target column (predict)
            train_data: pandas DataFrame with raw data to fit models
            test_data: pandas DataFrame to calculate out of sample estimation for models
            cv: one or a list of instances of [BaseCrossValidator, ShuffleSplit] or None (default)
            prediction_type: one out of 'classifier', 'regressor' or None (self detection)
            pipeline: sklearn Pipeline, last step must be ('estimator', None). If not it will be attached
            parameters: None or a tuple of 2 lists. First list contains one or multiple dictionaries with
                        parameters to all steps before estimator-step in pipeline or is empty,
                        Second list contains one or several dictionaries with parameters for last step 'estimator'
                        exp. params = ([{'prep__num_pipeline__imputer__strategy': ['mean', 'median']}],
                                       [{'estimator': [LogisticRegression()],
                                         'estimator__C': [0.1, 1, 10],
                                         'estimator__penalty': ['l2'],
                                        },
                                        {'estimator': [KNeighborsClassifier()]
                                        }])
                        if parameters is None, 'estimator' of pipeline (if available) is used to build parameters.
            

    """

    def __init__(self,
                 target: str,
                 train_data: pd.DataFrame,
                 test_data: Optional[Union[None, pd.DataFrame]] = None,
                 cv: Optional[Union[BaseCrossValidator, ShuffleSplit, list, None]] = None,
                 prediction_type: Optional[Union[None, str]] = None,
                 pipeline: Optional[Pipeline] = None,
                 parameters: Optional[tuple] = None,
                 grid: Optional[Union[None, str]] = "GridSearchCV",
                 ) -> None:

        if not isinstance(train_data, pd.DataFrame):
            raise ValueError(f"'data' has to be an instance pd.DataFrame")

        if not isinstance(target, str) or target not in train_data.columns:
            raise ValueError(f"'target' has to be a column name of data. actual value: {target}")

        self.train_data = train_data
        self.test_data = test_data
        self.target = target
        self.cv = self._build_cv(cv)
        self.X_train, self.y_train, self.X_test, self.y_test = self._build_x_y()
        self.prediction_type = self._build_type(prediction_type)
        self.parameters = self._build_parameters(parameters, pipeline)
        self.pipeline = self._build_pipeline(pipeline)
        self.grid = self._validate_grid(grid)
        self.fitted_results = {}
        self.predicted_results = {}
        self._cached_obj = None
        self._registered_models = []  # stores name of all used models
        self.fit_time = None
        self.scorer_names = []

    @classmethod
    def load(cls,
             path: Optional[str] = None
             ):
        """ loads a stored instance of a predictor object with a given path

        Args:
            path: path as string to a stored predictor object stored as .pkl. If None (default) the object will be
            searched in the working directory with it's default name

        Returns: an instance of a predictor object
        """
        return Storage.load(path=path)

    def save(self,
             path: Optional[str] = None
             ):
        """ stores an instance of the predictor object as pickle file

        Args:
            path: valid path as string with filename and ending .pkl to store an instance of predictor object
        """

        Storage(path=path).store(obj=self)

    def fit(self,
            refresh: Optional[bool] = False,
            cache: Optional[Union[bool, int]] = False,
            cache_path: Optional[Union[None, str]] = None,
            **kwargs) -> None:
        """ runs fitting and optimization
        Args:
            refresh: boolean, If False started (and broken) calculation are resumed, if True cached results are
            dropped and calculation are started new
            cache: should object be cached after a number of iterations? If False (default) nothing will be cached.
            If True the actual object will be cached after default number of iterations (10). If a numeric integer
            value the object will be cached after every multiple of this value.
            cache_path: string for path to store/cache actual object as .pkl or None (default). If None the object
            will be cached in the actual working directory.
            **kwargs: additional arguments for used self.grid (exp. GridSearchCV) as n_jobs, scoring, error, ...
        Returns: None
        """

        self.fit_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if refresh:
            self.fitted_results = {}
            self._registered_models = []
        cvs = self._get_outstanding_cvs()

        for i, cv in cvs.items():

            print(f"\n... processing {i}: {cv} ...")
            X_train, y_train = self.X_train, self.y_train

            result_algorithm = {}
            for idx, algorithm in enumerate(self.parameters[-1]):  # last list element in parameters are estimators

                print(f"algorithm: {algorithm}")
                estimator, pipe, updated_params = self._build_pipeline_and_params(algorithm)
                method_to_call = getattr(model_selection, self.grid)
                params = [i for i in inspect.signature(method_to_call, follow_wrapped=True).parameters]

                kwargs_mod = {"return_train_score": True}
                if kwargs:
                    kwargs_mod.update({key: value for (key, value) in kwargs.items() if key in params})
                    if 'scoring' in kwargs_mod and 'refit' not in kwargs_mod:
                        if isinstance(kwargs_mod.get('scoring'), dict):
                            kwargs_mod.update({'refit': list(kwargs_mod.get('scoring').keys())[0]})
                        else:
                            kwargs_mod.update({'refit': kwargs_mod.get('scoring')})    # if no refit is defined, take first scorer

                # add param_grid (GridSearchCV,...)  or param_distributions (RandomizedSearchCV) to kwargs_mod
                param_ = [i for i in params if 'param_' in i][0]  # does CV has a param_grid or param_distributions?
                kwargs_mod.update({param_: updated_params})

                model = method_to_call(estimator=pipe, cv=cv, **kwargs_mod)
                model.fit(X_train, y_train)
                name = self._get_model_name(estimator, i)
                result_algorithm.update({name: model})

            self.fitted_results.update({i: result_algorithm})
            self._build_scorer_names()

            # EVALUATOR to get best models (to build SHAP model in advance)
            # TODO: imported from same file (not from other due circular import)
            # evaluator = Evaluator(predictor=self)
            # evaluator.get_models(type='df')
            #
            # def NestedDictValues(d):
            #     for v in d.values():
            #         if isinstance(v, dict):
            #             yield from NestedDictValues(v)
            #         else:
            #             yield v
            #
            # best_models = list(set(NestedDictValues(evaluator.ranks)))
            # # or without Evaluator (at the moement)
            # best_models = ['0-0-1']  # first model -> in general: list with models to get shap-values
            # # TODO: use this best_models to calculate shap values (on server)
            # from explainerdashboard import ExplainerDashboard, ClassifierExplainer
            # import shap
            # self.explainer = {}
            # for best_model in best_models:
            #     # X = evaluator.predictor.X_train
            #     # y = evaluator.predictor.y_train.astype(int)
            #     X = self.X_train
            #     y = self.y_train.astype(int)
            #     model = evaluator.get_models(mode=best_model)
            #     estimator = model.get(list(model.keys())[0]).steps.pop()[1]
            #     X_trans = model.get(list(model.keys())[0]).transform(X)
            #     X_trans = pd.DataFrame(X_trans, columns=X.columns)
            #     estimator.fit(X_trans, y)
            #     # TODO (generalize)
            #     # TODO: if classifier (regressor)
            #     explainer = ClassifierExplainer(estimator, X_trans, y,
            #                                     X_background=shap.sample(X_trans, 5),
            #                                     labels=['HC', 'AD'],  # TODO
            #                                     cv=3,
            #                                     n_jobs=-1
            #                                     )
            #     self.explainer.update({best_model: explainer})
            # # TODO
            # print(self.explainer)

            if cache is not False:
                if self._cached_obj is None:
                    self._cached_obj = Storage(path=cache_path, cache=cache)
                # if cache would not be a multiple of number of simulations the last state of the object would
                # not be stored -> last iteration is marked by 'last'
                nr = lambda: 'last' if i + 1 == len(self.cv) else i
                self._cached_obj.cache_object(obj=self, cache_counter=nr())

    def predict(self,
                X: pd.DataFrame = None,
                mode: str = "all"
                ) -> None:
        """ predict values of train data or unseen data according to (best) models fitted
        Args:
            X:
            mode: one out of ['all', 'best'] or model-name as string

        Returns:
        """
        if len(self.fitted_results) == 0:
            raise Exception(f"There are no fitted objects! Use fit-method first!")

        if X is None:
            X = self.X_train
        else:
            if not isinstance(X, pd.DataFrame):
                raise Exception(f"X is not an instance of pd.DataFrame")
            if not all([i == j for i, j in zip(X.columns, self.X_train.columns)]):
                raise Exception(f"There are not the same columns or the columns are not in same order as on fitted X!")

        if mode == "all":  # calculates all predictions of all models (best hyper-parameters) in every simulation
            for item in self.fitted_results.items():
                results = {}
                for algorithm in item[1].items():
                    res = algorithm[1].predict(X)
                    results.update({algorithm[0]: res})
                self.predicted_results.update({item[0]: results})
        elif mode == "best":  # calculates only the prediction of the best model/algorithm in every simulation
            for item in self.fitted_results.items():
                score = {}
                for algorithm in item[1].items():
                    score.update({algorithm[0]: algorithm[1].best_score_})
                best = max(score.items(), key=operator.itemgetter(1))[0]
                res = item[1].get(best).predict(X)
                self.predicted_results.update({item[0]: {best: res}})
        else:  # calculates prediction of a given model name in every simulation
            if mode not in self._registered_models:
                raise Exception(f"unknown modelname! Available are: {self._registered_models}, Got: {mode}")
            else:
                for item in self.fitted_results.items():
                    res = item[1].get(mode).predict(X)
                    self.predicted_results.update({item[0]: {mode: res}})

    @staticmethod
    def _test_cv(cv):
        if not (isinstance(cv, BaseCrossValidator) or isinstance(cv, ShuffleSplit)):
            raise ValueError(f"'cv' has to be an instance of BaseCrossValidator or ShuffleSplit")

    def _build_cv(self, cv):
        if cv is None:
            cv_updated = {0: KFold(n_splits=5)}
        else:
            if isinstance(cv, list):
                cv_updated = {}
                for idx, item in enumerate(cv):
                    self._test_cv(item)
                    cv_updated.update({idx: item})
            else:
                self._test_cv(cv)
                cv_updated = {0: cv}
        return cv_updated

    @staticmethod
    def _build_pipeline(pipeline: Pipeline) -> Pipeline:
        """
        Args:
            pipeline: instance of Pipeline
        Returns: Pipeline with last step ('estimator': None)
        """
        if pipeline is None:
            pipeline = Pipeline(steps=[('estimator', None)])
            return pipeline
        else:
            if not isinstance(pipeline, Pipeline):
                raise ValueError(f"'pipeline has to be an instance of Pipeline or None")
            else:
                if 'estimator' in list(pipeline.named_steps.keys()):
                    if pipeline.steps[-1][0] == 'estimator' and pipeline.steps[-1][1] is None:
                        return pipeline
                    if pipeline.steps[-1][0] == 'estimator' and isinstance(pipeline.steps[-1][1], BaseEstimator):
                        pipeline.steps.pop(-1)  # drop estimator (last step in pipeline)
                        pipeline.steps.append(('estimator', None))  # add new estimator
                        return pipeline
                else:
                    pipeline.steps.append(('estimator', None))  # add new estimator
                    return pipeline

        raise Exception(f"something went wrong...")

    @staticmethod
    def _build_validation_sizes_random_states(test_sizes: Union[float, List[float]],
                                              random_states: Union[float, List[float]]) -> (List[float], List[float]):
        """ validates test_sizes and according random_states
        :param test_sizes: float or list of float for test_sizes (between 0 and 1)
        :param random_states: single random_state as int or list of int. random_states determines the number of
        'simulations' applied. If random_states is a single integer it will be interpreted as number of 'simulations'.
        If a specific random_seeds should be given to this method it has to be done as list (exp. [10])
        :return: list of test_sizes and list of random_states
        """
        # test_sizes
        if isinstance(test_sizes, float) and 0 < test_sizes < 1:
            test_sizes = [test_sizes]
        elif isinstance(test_sizes, list) and all([isinstance(i, float) and 0 < i < 1 for i in test_sizes]):
            test_sizes = test_sizes
        else:
            raise Exception(f"test_sizes have to be a single float or list of floats between 0 and 1")

        # random_states
        if isinstance(random_states, int):  # number of value of 'random_states' simulations
            random_states = random.sample(range(0, 1000), random_states)
        # exactly random_states of list -> number of list elements determine number of simulations
        elif isinstance(random_states, list) and all([isinstance(i, int) for i in
                                                      random_states]):
            random_states = random_states
        elif random_states is None:  # 1 'simulation'
            random_states = [random.randint(0, 1000)]
        else:
            raise Exception(f"random_states has to be None, single integer or list of integers")

        return test_sizes, random_states

    @staticmethod
    def _validate_grid(grid: str) -> Union[None, str]:
        if grid is not None and grid not in ['GridSearchCV', 'HalvingGridSearchCV', 'RandomizedSearchCV'
                                             # 'HalvingRandomSearchCV'
                                             ]:
            raise ValueError(
                f"'grid' has to be None or one of 'GridSearchCV', 'HalvingGridSearchCV' or 'RandomizedSearchCV'")
        return grid

    def _build_simulations(self) -> List[Tuple]:
        sim = list(itertools.product(self.random_states, self.validation_sizes))
        sim = {key: value for (key, value) in enumerate(sim)}
        return sim

    def _build_pipeline_and_params(self, algorithm):
        pipe = deepcopy(self.pipeline)
        algorithm_copy = algorithm.copy()
        if len(self.parameters[0]) != 0:
            updated_params = self.parameters[0][0].copy()
        else:
            updated_params = {}
        estimator = algorithm_copy.pop('estimator')[0]
        pipe.steps.pop(-1)  # drop estimator (last step in pipeline)
        pipe.steps.append(('estimator', estimator))  # add new estimator
        updated_params.update(algorithm_copy)
        return estimator, pipe, updated_params

    def _build_x_y(self) -> (pd.DataFrame, pd.Series):
        X_train = self.train_data.drop([self.target], axis=1)
        y_train = self.train_data[self.target]
        if self.test_data is not None:
            X_test = self.test_data.drop([self.target], axis=1)
            y_test = self.test_data[self.target]
        else:
            X_test = None
            y_test = None
        return X_train, y_train, X_test, y_test

    def _build_type(self, prediction_type: str) -> str:

        if prediction_type is None:
            if self.y_train.dtype.name in ['object', 'category'] or \
                    (self.y_train.dtype.name in ['int64', 'int32'] and len(self.y_train.unique()) <= 20):
                prediction_type = 'classifier'
            elif self.y_train.dtype.name in ['float64', 'float32'] or \
                    (self.y_train.dtype.name in ['int64', 'int32'] and len(self.y_train.unique()) > 20):
                prediction_type = "regressor"
        else:
            if prediction_type not in ['classifier', 'regressor']:
                raise ValueError(f"prediction_type must be one of 'classifier' or 'regressor'")
            elif prediction_type == "classifier":
                if not (self.y_train.dtype.name in ['object', 'category'] or
                        (self.y_train.dtype.name in ['int64', 'int32'] and len(self.y_train.unique()) <= 20)):
                    raise ValueError(
                        f"prediction_type 'classifier' is not compatible to target ({self.y_train.dtype.name})")
            elif prediction_type == "regressor":
                if not (self.y_train.dtype.name in ['float64', 'float32'] or
                        (self.y_train.dtype.name in ['int64', 'int32'] and len(self.y_train.unique()) > 20)):
                    raise ValueError(
                        f"prediction_type 'regressor' is not compatible to target ({self.y_train.dtype.name})")
            else:
                raise ValueError(f"prediction_type could not successfully validated as {prediction_type}. "
                                 f"Target '{self.target}' is of prediction_type {self.y_train.dtype}!")
        return prediction_type

    def _build_parameters(self, parameters: ([List, List]),
                          pipeline: Pipeline) -> ([List, List]):
        params = None
        error = f"parameters has to be a tuple containing 2 lists of dictionaries"

        if parameters is None and pipeline is not None:
            if pipeline.steps[-1][0] == 'estimator':
                if isinstance(pipeline.steps[-1][1], BaseEstimator):
                    parameters = ([{}], [{'estimator': [pipeline.steps[-1][1]]}])
                else:
                    if self.prediction_type == "classifier":
                        params = ([{}], [{'estimator': [KNeighborsClassifier()]}])
                    else:
                        params = ([{}], [{'estimator': [KNeighborsRegressor()]}])

        if parameters is None and pipeline is None:
            if self.prediction_type == "classifier":
                params = ([{}], [{'estimator': [KNeighborsClassifier()]}])
            else:
                params = ([{}], [{'estimator': [KNeighborsRegressor()]}])

        if parameters is not None:
            if not isinstance(parameters, tuple):
                raise ValueError(error)
            elif len(parameters) != 2:
                raise ValueError(error)
            elif not (isinstance(parameters[0], list) and isinstance(parameters[1], list)):
                raise ValueError(error)
            elif len(parameters[0]) != 0 and not all([isinstance(i, dict) for i in parameters[0]]):
                raise ValueError(error)
            elif len(parameters[1]) != 0 and not all([isinstance(i, dict) for i in parameters[1]]):
                raise ValueError(error)
            elif len(parameters[1]) != 0 and not all([isinstance(i.get('estimator')[0], BaseEstimator) for i
                                                      in parameters[1]]):
                raise ValueError(error)
            elif self.prediction_type == "classifier":
                if len(parameters[1]) != 0 and not \
                        all([is_classifier(i.get('estimator')[0]) for i in parameters[1]]):
                    raise ValueError(error)
            elif self.prediction_type == "regressor":
                if len(parameters[1]) != 0 and not \
                        all([is_regressor(i.get('estimator')[0]) for i in parameters[1]]):
                    raise ValueError(error)
            params = parameters
        return params

    def _get_model_name(self,
                        estimator: Union[ClassifierMixin, RegressorMixin],
                        i: int) -> str:
        """ builds model name from estimator name
        Args:
            estimator: Classifier or Regressor object
            i: int for number of simulation is running
        Returns: name of algorithm as string
        """
        if str(estimator).startswith("VotingClassifier"):
            name = "VotingClassifier"
        elif str(estimator).startswith("VotingRegressor"):
            name = "VotingRegressor"
        else:
            name = str(estimator)[:-2]

        # add name of all registered models to global list to prevent name conflicts (only in first simulation)
        if i == 0:
            if name not in self._registered_models:
                self._registered_models.append(name)
            else:
                j = 1
                while True:
                    name = name + f"_{j}"
                    if name not in self._registered_models:
                        self._registered_models.append(name)
                        break
                    else:
                        j += 1
        return name

    def _get_outstanding_cvs(self) -> Dict:
        """ if a fraction of simulations is already done, it will be evaluated where the process has to start again
         if broken. The method returns the list of outstanding (not already calculated) tuples. """
        if len(self.fitted_results) != 0:
            finished_calculations = list(self.fitted_results.keys())
            simulations = self.cv.copy()
            for key in finished_calculations:
                if key in simulations:
                    del simulations[key]
        else:
            simulations = self.cv
        return simulations

    def _build_scorer_names(self):
        scoring = self.fitted_results.get(0).get(list(self.fitted_results.get(0).keys())[0]).scoring
        if scoring is not None:
            if isinstance(scoring, str):
                self.scorer_names = [scoring]
            else:
                n = list(self.fitted_results.get(0).get(list(self.fitted_results.get(0).keys())[0]).scorer_.keys())
                self.scorer_names = n
        else:
            if self.prediction_type == "classifier":
                self.scorer_names = ["accuracy"]
            else:
                self.scorer_names = ["r2"]

    def __str__(self):

        fitted = lambda: True if len(self.fitted_results) != 0 else False

        predictor_dict = {'name': str(self.__class__),
                          'type': self.prediction_type,
                          'data': str(self.train_data.shape),
                          'fitted': str(fitted()),
                          }
        if fitted():
            predictor_dict.update({'fitted': self.fit_time,
                                   'simulations': str(self.cv),
                                   'GridSearchCVs': pformat(self.fitted_results)
                                   })

        predictor_str = "\n"
        for key, value in predictor_dict.items():
            predictor_str += f"{key}: {value}\n"

        return predictor_str


class Storage:
    """ This class is responsible for storage, load and cache of a Prediction object """

    def __init__(self,
                 path: Optional[Union[None, int]] = None,
                 cache: Optional[Union[bool, int]] = False):
        stack = inspect.stack()
        self.class_calling = stack[1][0].f_locals["self"].__class__.__name__
        self.method_calling = stack[1][0].f_code.co_name
        self.path = self._build_path(path)
        self.cache = cache
        self.next_cache_position = 0

    def _build_path(self, path):
        if path is None:
            path = Path(os.path.join(os.getcwd(), f'{self.class_calling}.pkl'))
        else:
            try:
                path = Path(path)
            except TypeError:
                raise Exception(f"could not convert {path} into a Path-object!")

            if not os.path.exists(path.parent):
                raise Exception(f"Path {path.parent} does not exist!")
            if not path.name.endswith('pkl'):
                raise Exception(f"File must be a .pkl file, actual it's a {path.name}!")
        return path

    def store(self,
              obj: Predictor
              ) -> None:
        """ stores object as .pkl file in given path
        Args:
            obj: Predictor object
        """

        try:
            with open(self.path, 'wb') as f:
                pickle.dump(obj, f)
        except FileNotFoundError:
            raise Exception(f"something went wrong...")

    def cache_object(self,
                     obj: Predictor,
                     cache_counter: Optional[Union[None, int, str]] = None
                     ) -> None:
        """ caches Prediction object after a given number of iterations. Last iteration will always be stored.
        Args:
            obj: Predictor object
            cache_counter: int number > 0 as indicator what loop was performed, 'last' or None
        """

        if self.cache is not False and (cache_counter == self.next_cache_position or cache_counter == "last"):
            self.store(obj=obj)
            self.next_cache_position += self.cache

    @classmethod
    def load(cls,
             path: Union[None, str] = None
             ) -> Predictor:
        """ loads an existing pickled file
        :param path: full path to location of pickled object by string with ending .pkl or None
        """
        try:
            with open(path, 'rb') as f:
                obj = pickle.load(f)
                return obj
        except FileNotFoundError:
            raise Exception(f"file not found '{path}'")

class Evaluator:

    def __init__(self,
                 predictor: Predictor,
                 test_data: Optional[Union[None, pd.DataFrame]] = None
                 ):
        self.predictor = self._check_predictor_instance(predictor)
        self.X_test, self.y_test = self._build_test_data(test_data)
        self.summary_object = {}
        self._scoring, self._train_score, self._used_models = self._get_predictor_params()
        self._prediction_type = self.predictor.prediction_type
        self._metrics = None
        self._summary_table = None
        self.ranks = {"best_sim_algo": None, "best_sim": None, "best": None}
        self._refit = self._get_refit()

    @staticmethod
    def _intersection(lst1, lst2):
        lst3 = [value for value in lst1 if value in lst2]
        return lst3

    @staticmethod
    def _check_predictor_instance(predictor):
        if not isinstance(predictor, Predictor):
            raise Exception(f"predictor has to be an instance of Predictor")
        return predictor

    @classmethod
    def load(cls, path=None):
        return Storage.load(path=path)

    def save(self, path=None):
        Storage(path=path).store(obj=self)

    def get_summary_object(self, type="default"):
        """ builds a summary dictionary of class evaluator (exp. for app-cards,...)
        Args:
            type: one out of 'default' or 'md' as str. 'md' formats output with markdown-style

        Returns: dictionary with summary of object

        """
        self._build_summary_object(type=type)
        return self.summary_object

    def get_models(self,
                   mode: Optional[Union[str, list]] = "all",
                   type: Optional[str] = 'fitted_obj',
                   metric: Optional[Union[None, str]] = None
                   ) -> Union[pd.DataFrame,]:
        """
        get models from simulations according to its 'id' or other parameters and returns it as
        pd.Dataframe or fitted object.

        Args:
            mode: one out of 'all', 'best', 'best_sim', 'best_sim_algo' id (as string) or list of id's
            type: one out of 'fitted_obj' for fitted object (to calculate predictions or else), 'df' for pd.DataFrame
            metric: one out of used metrics (exp. accuracy, rmse, ...) or None (default -> use standard metric).
            Metric is used to find 'best' model according to this metric in case of mode='best' """

        if self._summary_table is None:
            self._build_summary_table()

        self._build_ranks(metric=metric)

        if mode == "all":
            ids = {i: i for i in self._summary_table['id']}
        elif mode == "best":
            ids = {'_': self.ranks[mode]}
        elif mode in ['best_sim', 'best_sim_algo']:
            ids = self.ranks[mode]
        elif isinstance(mode, str):
            ids = self._summary_table[self._summary_table['id'] == mode]['id']
            if len(ids) != 1:
                ids = {}
            else:
                ids = {mode: ids.values[0]}
        elif isinstance(mode, list):
            ids = {i: i for i in self._summary_table['id'] if i in mode}
        else:
            ids = {}

        results = {}

        # TODO: what happens if there is no cv_results_ ...?
        # TODO: -> catch if mode='all' and these are +1000 algorithms
        if type == 'fitted_obj':
            for id in ids.values():
                sim, model, idx = id.split("-")
                model_for_id = copy.deepcopy(
                    self.predictor.fitted_results.get(int(sim)).get(self._used_models.get(model)).estimator)
                params_for_id = \
                    self.predictor.fitted_results.get(int(sim)).get(self._used_models.get(model)).cv_results_.get(
                        'params')[
                        int(idx)]
                model_for_id.set_params(**params_for_id)
                fitted_model = model_for_id.fit(X=self.predictor.X_train, y=self.predictor.y_train)
                results.update({id: fitted_model})

        elif type == 'df':
            if mode == "all":
                results = self._summary_table
            else:
                results = self._summary_table[self._summary_table.id.isin(ids.values())]

        return results

    def get_summary_plot(self,
                         mode: Optional[str] = "all",
                         metric: Optional[Union[str, None]] = None,
                         color: Optional[List[str]] = "metric",
                         x: Optional[str] = "algorithm",
                         boxpoints: Optional[str] = 'all',
                         boxmean: Optional[str] = 'True',
                         jitter: Optional[float] = 0.2,
                         opacity: Optional[float] = 1,
                         yrange: Optional[List[float]] = [0.0, 1.0],
                         path: Optional[str] = None,
                         df: Optional[pd.DataFrame] = None
                         ):
        """
        Args:
            mode: one out of 'all', 'best', 'best_sim', 'best_sim_algo' id or list of id's
            metric: name of metric for finding best model as string. Only usable if model="best"
            color: list of strings, one or multiple out of ['algorithm', 'group', 'metric' 'sim', 'params' or None]
            x: parameter for x-axis: one out of ['algorithm', 'group', 'metric', 'sim', 'params']
            boxpoints: one out of 'all', 'suspectedoutliers', 'outliers', 'False'
            boxmean: one out of 'True', 'sd', 'False'
            jitter: a float value between 0 and 1 for jittering boxpoints
            opacity: a float value between 0 and 1 for opacity
            yrange: a list of 2 floats for starting and endpoint of y-axis scale
            path: where should the plots be stored? If None (default) is set, the plots are only returned but not stored

        Returns: plotly figure
        """
        if df is None:
            df = self.get_models(mode=mode, metric=metric, type="df")
        df_mod = self._build_summary_plot_data(df)

        if df_mod is not None:
            fig = self._build_summary_plot_figure(boxmean, boxpoints, color, df_mod, jitter, opacity, x, yrange)
        else:
            fig = {}

        if path is None:
            return fig
        else:
            default_name = f'summary_plot.html'
            store_path = PathValidator(path, default_name=default_name,
                                       valid_suffix=['.html']).get_validated_path()
            if store_path is not None:
                fig.write_html(str(store_path))
            else:
                raise Exception(f"could not write plots to disk! Unknown Path: {path}")

    def _build_test_data(self, test_data):
        if test_data is None:
            if self.predictor.X_test is not None and self.predictor.y_test is not None:
                X_test = self.predictor.X_test
                y_test = self.predictor.y_test
            else:
                X_test = None
                y_test = None
        else:
            if not isinstance(test_data, pd.DataFrame):
                raise Exception(f"'test_data has to be an instance of pd.DataFrame")
            if self.predictor.target not in test_data.columns:
                raise Exception(f"'test_data' does not contain the target-column '{self.predictor.target}'")
            else:
                y_test = test_data[self.predictor.target]
                X_test = test_data.drop(self.predictor.target, axis=1)
                if X_test.shape[1] != self.predictor.X_train.shape[1]:
                    raise Exception(f"X_train ({self.predictor.X_train.shape[1]}) and "
                                    f"X_test ({X_test.shape[1]}) have not the same shape!")
                if len(self._intersection(list(X_test.columns), list(self.predictor.X_train.columns))) != X_test.shape[
                    1]:
                    raise Exception(f"Not all columns in X_test and X_train seems to have same name!")

        return X_test, y_test

    def _build_summary_table(self):
        """
        builds a summary table with results of all simulations and all combinations of hyper-parameters

        Args:
            -
        Returns:
            None
        """
        df = self._collect_results()
        df = self._replace_score_with_metric_unit(df)
        df = self._add_test_scores(df)
        self._calculate_metrics()
        df = self._remove_splits(df)  # remove splits due incompatible cv's
        df = self._calculate_mean_train_diff(df)

        df['sim_algo'] = df['id'].apply(lambda x: '-'.join(x.split("-")[:-1]))
        # rearrange columns
        first_cols = ['sim', 'sim_algo', 'id', 'algorithm']
        cols = list(df.columns)
        not_in_first_cols = [i for i in cols if i not in first_cols]
        new_cols = first_cols + not_in_first_cols
        df = df[new_cols]
        self._summary_table = df

    def _calculate_mean_train_diff(self, df):
        # build mean_diff (mean_train -mean_validation)
        mean_train = [i for i in df.columns if "mean_train" in i]
        if mean_train:
            if len(self.predictor.scorer_names) != 0:
                for item in self.predictor.scorer_names:
                    df[f'mean_diff_{item}'] = df[f'mean_train_{item}'] - df[f'mean_validation_{item}']
            else:
                if self.predictor.prediction_type == "classifier":
                    df[f'mean_diff_accuracy'] = df[f'mean_train_accuracy'] - df[f'mean_validation_accuracy']
                else:
                    df[f'mean_diff_r2'] = df[f'mean_train_r2'] - df[f'mean_validation_r2']
        return df

    def _remove_splits(self, df):
        columns = ['id', 'sim', 'algorithm', 'params'] + self._metrics
        df = df.loc[:, columns]
        return df

    def _add_test_scores(self, df):
        # only best model for a simulation/algorithm combination (could also be done for every combination...)
        if self.X_test is not None and self.y_test is not None:
            test_scores = []
            for sim in list(self.predictor.fitted_results.keys()):
                for algorithm in list(self.predictor.fitted_results.get(sim).keys()):
                    scorer_name = []
                    score = []
                    model = self.predictor.fitted_results.get(sim)[algorithm]
                    if isinstance(model.scorer_, dict):
                        preds = model.predict(self.X_test)
                        keys = model.scorer_.keys()
                        for key in keys:
                            sc = model.scorer_.get(key)
                            scorer_name.append(key)
                            score.append(sc._score_func(self.y_test, preds))
                    else:
                        scorer_name.append(self._scoring[0])
                        score = [model.score(self.X_test, self.y_test)]  # only for best_estimator...
                    simple_list = [[sim, algorithm] + score]
                    df_testscore = pd.DataFrame(simple_list, columns=['sim', 'algorithm'] + [f"mean_test_{i}" for i in
                                                                                             scorer_name])  # TODO: replace 'mean' with better word...
                    test_scores.append(df_testscore)
            test_scores = pd.concat(test_scores)
            df = pd.merge(df, test_scores, on=['sim', 'algorithm'])
        return df

    def _calculate_metrics(self):
        """
        calculates train and test metrics according to given metric and if train score was returned or not.

        Args:
            -
        Returns:
            None
        """
        if self.X_test is not None:
            if self._train_score is not False:
                self._metrics = [i[0] + i[1] for i in
                                 itertools.product(['mean_train_', 'mean_validation_', 'mean_test_'], self._scoring)]
            else:
                self._metrics = [i[0] + i[1] for i in
                                 itertools.product(['mean_validation_', 'mean_test_'], self._scoring)]
        else:
            if self._train_score is not False:
                self._metrics = [i[0] + i[1] for i in
                                 itertools.product(['mean_train_', 'mean_validation_'], self._scoring)]
            else:
                self._metrics = [i[0] + i[1] for i in itertools.product(['mean_validation_'], self._scoring)]

    def _replace_score_with_metric_unit(self,
                                        df: pd.DataFrame
                                        ) -> pd.DataFrame:
        """
        replace 'score' with correct unit. If only one metric is set (exp. accuracy) the column is called 'score'
        by default. This will be replaced with the name of the according metric (exp. test_score -> test_accuracy)
        """
        if self._scoring is None:  # take default scorer (accuracy for classification and ? for regression)
            if self._prediction_type == 'classifier':
                self._scoring = ["accuracy"]
            else:
                self._scoring = ["?"]  # TODO
            df = self._replace_score(df)
        elif isinstance(self._scoring, str):
            self._scoring = [self._scoring]
            df = self._replace_score(df)
        elif isinstance(self._scoring, list):
            df = self._replace_score(df)
        else:  # in case if dict
            self._scoring = list(self._scoring.keys())
        return df

    def _collect_results(self
                         ) -> pd.DataFrame:
        """
        collects all results in a pandas DataFrame and add a unique id for every row (a-b-c):
        a -> simulation number,
        b -> algorithm number,
        c -> consecutive number

        Args:
            -
        Returns:
            pandas DataFrame
        """

        dfs = []  # collect results
        for sim_nr, sim in self.predictor.fitted_results.items():
            for idx, est_name in enumerate(sim.keys()):
                this_df = pd.DataFrame(sim[est_name].cv_results_)

                # TODO: here rename test -> validation
                new_colnames = [w.replace('_test_', '_validation_') for w in list(this_df.columns)]
                this_df.columns = new_colnames

                this_df['sim'] = sim_nr
                this_df['algorithm'] = est_name
                this_df['id'] = [f"{sim_nr}-{idx}-{i}" for i in list(this_df.index)]
                this_df = this_df.loc[:, ~ this_df.columns.str.contains("param_")]
                dfs.append(this_df)
        df = pd.concat(dfs, ignore_index=True)
        return df

    def _build_ranks(self,
                     metric: Union[None, str],
                     ) -> dict:
        """
        catches best models according to chosen metric from summary_table

        Args:
            metric: name of desired metric (exp. accuracy, f1, ...)

        Returns:
            dictionary with 'best', 'best_sim' and 'best_sim_algo' as key and 'id' as list of values
        """

        if metric is None:
            validation_list = [i for i in self._metrics if "validation_" in i]
            rank_metric = validation_list[0]
        else:
            if metric not in self._scoring:
                raise Exception(f"metric '{metric}' was not fitted. Use one of {self._scoring}")
            rank_metric = f"mean_validation_{metric}"

        df = self._summary_table

        # best per algorithm and simulation
        # df['sim_algo'] = df['id'].apply(lambda x: '-'.join(x.split("-")[:-1]))
        grouped_df = df.groupby('sim_algo')
        best_sim_algo = {}
        for name, group in grouped_df:
            best_id = group[group[rank_metric] == max(group[rank_metric])]['id'].values[
                0]  # TODO: whats best? Min? Max?
            best_sim_algo.update({name: best_id})
        self.ranks.update({'best_sim_algo': best_sim_algo})

        # best per simulation (test_size, random_state)
        grouped_df = df.groupby('sim')
        best_sim = {}
        for name, group in grouped_df:
            best_id = group[group[rank_metric] == max(group[rank_metric])]['id'].values[0]
            best_sim.update({f'{name}': best_id})
        self.ranks.update({'best_sim': best_sim})

        # overall
        self.ranks.update({"best": df[df[rank_metric] == max(df[rank_metric])]['id'].values[0]})

    def _get_predictor_params(self):
        scoring, train_score, used_models = None, None, None
        if self.predictor.fitted_results:
            used_models = {str(idx): algoritm for idx, algoritm in
                           enumerate(self.predictor.fitted_results.get(0).keys())}
            scoring = self.predictor.fitted_results.get(0).get(used_models.get('0')).scoring
            train_score = self.predictor.fitted_results.get(0).get(used_models.get('0')).return_train_score
        return scoring, train_score, used_models

    def _replace_score(self,
                       df: pd.DataFrame
                       ) -> pd.DataFrame:

        cols = list(df.columns)
        cols_0 = [i.replace('validation_score', f'validation_{self._scoring[0]}') for i in cols]
        cols_1 = [i.replace('train_score', f'train_{self._scoring[0]}') for i in cols_0]
        df.columns = cols_1
        return df

    def _build_summary_plot_data(self,
                                 df: pd.DataFrame
                                 ) -> pd.DataFrame:
        """
        build data for subsequently plotting

        Args:
            df: pd.DataFrame with raw data

        Returns:
            modified pandas DataFrame

        """
        if df.shape == (0, 0):
            return None
        else:
            df_mod = df.melt(id_vars=['id', 'sim', 'algorithm', 'params'],
                             value_vars=self._metrics)

        def split(s):
            var = s.variable
            var = var.replace("_", ".", 2)  # replace first 2 occurrences of '_' by '.' to split afterwards
            return var

        df_mod[['variable']] = df_mod.apply(split, axis=1)
        df_mod[['stat', 'group', 'metric']] = df_mod.variable.str.split(".", expand=True)
        df_mod['params'] = df_mod.params.apply(lambda x: str(x))
        return df_mod

    def _get_refit(self):
        refit = self.predictor.fitted_results.get(0).get(self._used_models['0']).refit
        if refit is True:
            refit = self._scoring
        return refit

    @staticmethod
    def _build_summary_plot_figure(
            boxmean: str,
            boxpoints: str,
            color: List[str],
            df_mod: pd.DataFrame,
            jitter: float,
            opacity: float,
            x: str,
            yrange: List[float],
    ) -> go.Figure:

        """
        builds figure for summary plot

        Args:
            - see Args: get_summary_plot()
        Returns:
            Figure object
        """
        bp = lambda x: x if x != 'False' else eval(x)
        bm = lambda x: x if x == 'sd' else eval(x)

        fig = go.Figure()
        grouped = df_mod.groupby(color)
        for name, group in grouped:
            fig.add_trace(go.Box(
                y=group['value'],
                x=group[x],
                boxpoints=bp(boxpoints),
                boxmean=bm(boxmean),
                jitter=jitter,
                opacity=opacity,
                name=str(name),
                customdata=group.loc[:,
                           ['id', 'algorithm', 'params', 'stat', 'group', 'metric']],

                hovertemplate=
                "<b>score:</b> %{y} <br><br>" +
                "id: %{customdata[0]} <br>" +
                "algorithm: %{customdata[1]} <br>" +
                "parameters: %{customdata[2]} <br>" +
                "stat: %{customdata[3]} <br>" +
                "group: %{customdata[4]} <br>" +
                "metric: %{customdata[5]} <br>"
            ))

        fig.update_layout(
            template='plotly_white',
            boxmode='group',  # group together boxes of the different traces for each value of x
            yaxis_range=[yrange[0], yrange[1]]
        )

        return fig

    def _build_summary_object(self, type):

        def get_simulations(type):
            sim = self.predictor.cv
            sim_desc = list(sim.values())
            if type == "md":
                sim = [f"{n}: {str(i)}\n" for n, i in enumerate(sim_desc)]
                sim = '\n'.join(sim)
            else:
                sim = [f"{n}: {str(i)}\n" for n, i in enumerate(sim_desc)]
            return sim

        def get_used_models(type):
            used_models = list(self.predictor.fitted_results[0].keys())
            if type == "md":
                used_models = [f"* {i} ({n})\n" for n, i in enumerate(used_models)]
            else:
                used_models = '\n'.join(used_models)
            return used_models

        def get_train_test_size(type):
            shape_train = self.predictor.X_train.shape
            if type == "md":
                formatted_shape_train = f"* X_train: ({shape_train[0]} observations, {shape_train[1]} features)"
            else:
                formatted_shape_train = f"X_train: ({shape_train[0]} observations, {shape_train[1]} features)"
            if self.predictor.X_test is not None:
                shape_test = self.predictor.X_test.shape
                if type == "md":
                    formatted_shape_test = f"* X_test: ({shape_test[0]} observations, {shape_test[1]} features)"
                else:
                    formatted_shape_test = f"X_test: ({shape_test[0]} observations, {shape_test[1]} features)"
                formatted_shape = "\n".join(formatted_shape_train, formatted_shape_test)
            else:
                formatted_shape = formatted_shape_train
            return formatted_shape

        self.summary_object.update({
            'obj_type': self.predictor.prediction_type,
            'fit_time': self.predictor.fit_time,
            'grid': self.predictor.grid,
            'target': self.predictor.target,
            'used_models': get_used_models(type=type),
            'simulations': get_simulations(type=type),
            'no_models': self.get_models(mode="all", type="df").shape[0],
            'fig_pipeline': estimator_html_repr(self.predictor.pipeline),
            'scorer': self.predictor.scorer_names,  # TODO!
            'parameters': "\n".join([str(self.predictor.parameters[0]),  # TODO!
                                     str(self.predictor.parameters[1])]),
            'size_train_test_data': get_train_test_size(type=type)
        })

if __name__ == '__main__':
    pass

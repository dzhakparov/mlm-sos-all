import os
from typing import List, Optional, Union, Dict
from pathlib import Path


class Logger:
    def __init__(self, log, log_path, log_type):
        self.log_path = log_path
        self.log_type = log_type
        self.file = None
        self.log = self._initialize_log(log)

    def _initialize_log(self, log):
        if not isinstance(log, bool):
            raise Exception("log has to be type 'bool'")
        if log:
            if not self.log_path:
                self.log_path = Path(os.getcwd()).joinpath('logs')
            if not os.path.exists(self.log_path):
                try:
                    os.mkdir(self.log_path)
                    self.file = f"{self.log_path}/predictor.log"
                except FileNotFoundError:
                    raise Exception(f"path {self.log_path} does not exist!")
            else:
                self.file = f"{self.log_path}/predictor.log"
        return log
from sklearn.feature_selection import SelectKBest
import pandas as pd


class SelectKBest(SelectKBest):
    def __init__(self, df_out=True, k=10):
        super().__init__(k=k)
        self.df_out = df_out
        self.features_out = None

    def fit(self, X, y=None):
        super().fit(X, y)
        return self

    def transform(self, X):
        data = super().transform(X)
        selected_features = self.get_support(indices=False)
        self.features_out = list(X.columns[selected_features])

        if self.df_out:
            data = pd.DataFrame(data=data, columns=self.features_out)
        return data

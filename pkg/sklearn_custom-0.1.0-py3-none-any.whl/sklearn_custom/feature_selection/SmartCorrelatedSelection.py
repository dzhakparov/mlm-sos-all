from typing import List, Union
import pandas as pd
from feature_engine.selection.smart_correlation_selection import SmartCorrelatedSelection

Variables = Union[None, int, str, List[Union[str, int]]]


class SmartCorrelatedSelection(SmartCorrelatedSelection):
    """
        SmartCorrelatedSelection() finds groups of correlated features and then selects,
        from each group, a feature following certain criteria:
        - Feature with least missing values
        - Feature with most unique values
        - Feature with highest variance
        - Best performing feature according to estimator entered by user
        SmartCorrelatedSelection() returns a dataframe containing from each group of
        correlated features, the selected variable, plus all original features that were
        not correlated to any other.
        Correlation is calculated with `pandas.corr()`.
        SmartCorrelatedSelection() works only with numerical variables. Categorical
        variables will need to be encoded to numerical or will be excluded from the
        analysis.
        source: https://github.com/solegalli/feature_engine/blob/master/feature_engine/selection/smart_correlation_selection.py
    """
    def __init__(self,
                 variables: Variables = None,
                 method: str = "pearson",
                 threshold: float = 0.8,
                 missing_values: str = "ignore",
                 selection_method: str = "missing_values",
                 estimator=None,
                 scoring: str = "roc_auc",
                 cv=3,
                 df_out=True,
                 ):
        super().__init__(variables=variables,
                         method=method,
                         threshold=threshold,
                         missing_values=missing_values,
                         selection_method=selection_method,
                         estimator=estimator,
                         scoring=scoring,
                         cv=cv)
        self.df_out = df_out
        self.features_out = None

    def fit(self, X, y=None):
        super().fit(X, y)
        return self

    def transform(self, X):
        data = super().transform(X)
        self.features_out = [i for i in self.variables_ if i not in self.features_to_drop_]

        if self.df_out is False:
            data = data.values
        return data
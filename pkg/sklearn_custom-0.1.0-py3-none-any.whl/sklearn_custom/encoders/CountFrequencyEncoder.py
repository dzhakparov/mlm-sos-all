from feature_engine.encoding.count_frequency import CountFrequencyEncoder


class CountFrequencyEncoder(CountFrequencyEncoder):
    def __init__(self, df_out=True, encoding_method="count", variables=None):
        super().__init__(encoding_method=encoding_method, variables=variables)
        self.df_out = df_out

    def fit(self, X, y=None):
        for col in X.columns:
            if X[col].dtype.name == "category":
                X[col] = X[col].astype('O')
        super().fit(X, y)
        return self

    def transform(self, X):
        for col in X.columns:
            if X[col].dtype.name == "category":
                X[col] = X[col].astype('O')
        df = super().transform(X)
        if self.df_out is False:
            df = df.values
        return df

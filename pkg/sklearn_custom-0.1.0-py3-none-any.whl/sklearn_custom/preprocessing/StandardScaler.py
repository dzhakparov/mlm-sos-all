from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np


class StandardScaler(StandardScaler):

    def __init__(self, df_out=True, **kwargs):
        super().__init__(**kwargs)
        self.df_out = df_out

    def fit(self, X, y=None):
        super().fit(X, y=y)
        return self

    def transform(self, X):
        Xs = super().transform(X)

        if self.df_out and isinstance(X, pd.DataFrame):
            idx = X.index
            cols = X.columns.to_list()
            Xs = pd.DataFrame(data=Xs, index=idx, columns=cols)

        return Xs
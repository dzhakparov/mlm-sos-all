
class Testresults:

    def __init__(self, testname=None, pvalue=None, pvalue_corrected=None, grouped_by=None, group_levels=None, feature=None,
                 no_observations=None, means=None, stats=None, normality=None, normality_manual=None,
                 var_homogeneity=None, expected_freq=None, post_hoc=None, post_hoc_test=None, feature_type=None):

        self.testname = testname
        self.pvalue = pvalue
        self.pvalue_corrected= pvalue_corrected
        self.grouped_by = grouped_by
        self.group_levels = group_levels
        self.means = means
        self.stats = stats
        self.feature = feature,
        self.feature_type = feature_type,
        self.no_observations = no_observations
        self.normality = normality
        self.normality_manual = normality_manual
        self.var_homogeneity = var_homogeneity
        self.expected_freq = expected_freq
        self.post_hoc = post_hoc
        self.post_hoc_test = post_hoc_test
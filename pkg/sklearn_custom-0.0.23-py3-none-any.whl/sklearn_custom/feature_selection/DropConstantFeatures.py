from typing import List, Union
from feature_engine.selection.drop_constant_features import DropConstantFeatures

Variables = Union[None, int, str, List[Union[str, int]]]


class DropConstantFeatures(DropConstantFeatures):
    """
    Drop constant and quasi-constant variables from a dataframe. Constant variables
    show the same value across all the observations in the dataset. Quasi-constant
    variables show the same value in almost all the observations in the dataset.
    By default, DropConstantFeatures() drops only constant variables. This transformer
    works with both numerical and categorical variables. The user can indicate a list
    of variables to examine. Alternatively, the transformer will evaluate all the
    variables in the dataset.
    The transformer will first identify and store the constant and quasi-constant
    variables. Next, the transformer will drop these variables from a dataframe.
    source: https://github.com/solegalli/feature_engine/blob/master/feature_engine/selection/drop_constant_features.py
    """
    def __init__(self,
                 variables: Variables = None,
                 tol: float = 1,
                 missing_values: str = "raise",
                 df_out=True,
                 ):
        super().__init__(variables=variables,
                         tol=tol,
                         missing_values=missing_values)
        self.df_out = df_out

    def fit(self, X, y=None):
        super().fit(X, y)
        return self

    def transform(self, X):
        data = super().transform(X)

        if self.df_out is False:
            data = data.values
        return data
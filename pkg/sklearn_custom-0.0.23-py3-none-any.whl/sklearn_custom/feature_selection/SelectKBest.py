from sklearn.feature_selection import SelectKBest
import pandas as pd


class SelectKBest(SelectKBest):
    def __init__(self, df_out=True, k=10):
        super().__init__(k=k)
        self.df_out = df_out

    def fit(self, X, y=None):
        super().fit(X, y)
        return self

    def transform(self, X):
        data = super().transform(X)

        if self.df_out:
            selected_features = self.get_support(indices=False)
            selected_names = list(X.columns[selected_features])
            data = pd.DataFrame(data=data, columns=selected_names)
        return data
